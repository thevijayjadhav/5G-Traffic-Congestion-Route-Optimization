# 5G Traffic Congestion & Route Optimization

A portfolio project built from the supplied telecom network workbook.

## Deliverables
- `index.html` — standalone interactive dashboard (open in a browser)
- `5G_Traffic_Analysis_Cleaned.csv` — source records plus engineered features and routing recommendations
- `Node_Congestion_Summary.csv` — node-type-level summary
- `Service_Traffic_Summary.csv` — service-level summary
- `Congestion_Zone_Summary.csv` — node type by congestion band
- `PowerBI_Guide_DAX_and_Routing_Logic.txt` — Power BI pages, DAX, assumptions and next data requirements

## Dataset snapshot
- 5,000 rows; 8 original columns
- Network status: Normal 3,809; Congested 854; Fault 337
- Missing cells in required source columns: 0

## Important limitation
No timestamp, unique base-station/gateway identifiers, route IDs, path topology, or link capacities
are present. Peak-hour and geographic hotspot claims, and real end-to-end route optimization,
cannot be validated from this file. The route recommendations are rule-based suggestions for
portfolio demonstration only.
